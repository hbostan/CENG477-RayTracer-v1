#ifndef __HW1__PARSER__
#define __HW1__PARSER__

#include <iostream>
#include <math.h>
#include <string>
#include <vector>
#include "Vector.h"
#include "Camera.h"
#include "Shape.h"
#include "Ray.h"
#include "ppm.h"
using namespace std;
namespace parser
{
	/*struct Camera
	{
		Point position;
		Vec3f gaze;
		Vec3f up;
		Vec4f near_plane;
		float near_distance;
		int image_width, image_height;
		std::string image_name;
	};*/

	struct PointLight
	{
		Vec3f position;
		Vec3f intensity;
	};

	struct Material
	{
		Vec3f ambient;
		Vec3f diffuse;
		Vec3f specular;
		Vec3f mirror;
		float phong_exponent;
	};

	struct Face
	{
		int v0_id;
		int v1_id;
		int v2_id;
	};

	struct Mesh
	{
		int material_id;
		std::vector<Face> faces;
	};

	struct Triangle
	{
		int material_id;
		Face indices;
	};

	/*struct Sphere
	{
		int material_id;
		int center_vertex_id;
		float radius;
	};*/

	struct Scene
	{
		//Data
		Vec3i background_color;
		float shadow_ray_epsilon;
		int max_recursion_depth;
		std::vector<Camera> cameras;
		Vec3f ambient_light;
		std::vector<PointLight> point_lights;
		std::vector<Material> materials;
		std::vector<Vec3f> vertex_data;
		std::vector<Mesh> meshes;
		std::vector<Triangle> triangles;
		std::vector<Sphere> spheres;

		/*float SphereIntersect(const Ray &ray, const Sphere &sphere)
		{
			float root1, root2;

			Vec3f direction = ray.direction;
			Vec3f distance_vector = ray.origin - vertex_data[sphere.center_vertex_id];
			
			float A = direction.dot(direction);
			float B = direction.dot(distance_vector) * 2;
			float C = distance_vector.dot(distance_vector) - sphere.radius * sphere.radius;

			float discriminant = B * B - 4 * A * C;
			if(discriminant < 0) return false;
			else
			{
				discriminant = sqrt(discriminant);
				root1 = (-B + discriminant)/(2*A);
				root2 = (-B - discriminant)/(2*A); 
			}

			float small = root1 < root2 ? root1 : root2;
			float big = root1 > root2 ? root1 : root2;

			if(small < 0)
			{
				if(big < 0) return -1;
				return big;
			}
			else
			{
				return small;
			}

		}*/

		void Render(Camera &camera)
		{
			camera.initCamera();
			unsigned char* image = new unsigned char[camera.image_width * camera.image_height * 3];

			int i = 0;
			for(int y = 0; y < camera.image_height; ++y)
			{
				for(int x = 0; x < camera.image_width; ++x)
				{
					Ray ray = camera.makeRay(x, y);

					for(auto it = spheres.begin(); it != spheres.end(); it++)
					{
						(*it).center = vertex_data[(*it).center_vertex_id];

						i = (y * camera.image_width + x) * 3;
						Intersection intersection(ray);
						it->intersect(intersection);
						if(intersection.pSphere)
						{
							image[i++] = 255;
							image[i++] = 0;
							image[i++] = 255;
						}
						else
						{
							image[i++] = 0;
							image[i++] = 0;
							image[i++] = 0;
						}
					}
				}
			}

			write_ppm("test.ppm", image, camera.image_width, camera.image_height);
		}

		//Functions
		void loadFromXml(const std::string& filepath);
	};
}

#endif
