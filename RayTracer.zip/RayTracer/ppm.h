#ifndef __ppm_h__
#define __ppm_h__

void write_ppm(const char* filename, unsigned char* data, int width, int height);

#endif // __ppm_h__

