#include "Ray.h"

/*Ray::Ray(Point origin, Vec3f direction)
{
    this->origin = origin;
    this->direction = direction;
}*/